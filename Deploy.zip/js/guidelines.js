function showhidden() {
    document.getElementById('hidden').style.display="block"
}